use (function(){
    var value1 = java.util.Date().toString();
    var value2 = value1.split("\\s");
    var value3 = value2[3];
    
    return{
        datetime: value3
    };
});