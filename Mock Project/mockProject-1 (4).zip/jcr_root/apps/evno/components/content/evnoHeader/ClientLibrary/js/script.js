$(document).ready(function(e){
    $('.head-button').on('click',function(){
 alert("I am a pop up ! ");
});